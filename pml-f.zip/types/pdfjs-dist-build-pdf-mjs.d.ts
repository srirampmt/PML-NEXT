declare module "pdfjs-dist/build/pdf.mjs" {
  export * from "pdfjs-dist";
}
